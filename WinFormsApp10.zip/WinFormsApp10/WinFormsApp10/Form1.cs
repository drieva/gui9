using System;
using System.Windows.Forms;

namespace PaintingEstimate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Get length and width values from textboxes
            if (double.TryParse(lengthTextBox.Text, out double length) && double.TryParse(widthTextBox.Text, out double width))
            {
                double price = CalculatePaintingEstimate(length, width);
                MessageBox.Show($"The estimated cost for painting the room is: ${price:F2}");
            }
            else
            {
                MessageBox.Show("Please enter valid numeric values for length and width.");
            }
        }

        private double CalculatePaintingEstimate(double length, double width)
        {
            const double pricePerSquareFoot = 6.0;
            const double ceilingHeight = 9.0;
            double area = (length * 2 + width * 2) * ceilingHeight;
            return area * pricePerSquareFoot;
        }
    }
}
